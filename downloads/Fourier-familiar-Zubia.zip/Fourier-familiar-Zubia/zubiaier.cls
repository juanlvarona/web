%%% ====================================================================
%%% @LaTeX-file{
%%%    filename  = "zubiaier.cls",
%%%    version   = "1.0",
%%%    date      = "2014/10/06",
%%%    time      = "00:00:00 EDT",
%%%    author    = "Juan L. Varona",
%%%    address   = "Dpto. Matem\'aticas y Computaci\'on,
%%%                       Universidad de La Rioja,
%%%                       26004 Logro\~no, Spain",
%%%    email     = "jvarona@unirioja.es",
%%%    url       = "http://www.unirioja.es/cu/jvarona/",
%%%    license   = "LaTeX Project Public License (LPPL), any version",
%%%    abstract  = "This is the zubiaier LaTeX class.
%%%                 It is intended to write papers for <<Zub\'{\i}a>>, 
%%%                 a journal of the Instituto de Estudios Riojanos,                 
%%%                 http://www.larioja.org/npRioja/default/defaultpage.jsp?idtab=451955
%%%                 This class is based on article, with many
%%%                 customizations and additions. 
%%%                 Moreover, the packages 
%%%                 garamond, garamondx, mathdesign, cinzel,
%%%                 geometry, babel (with english and spanish), url, 
%%%                 fancyhdr, color, amsmath, amsthm, and amssymb
%%%                 are always loaded".
%%% }
%%% ====================================================================


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                    %
% Clase para Zubia (IER), ver.1.0                                    %
%                                                                    %
% Instituto de Estudios Riojanos                                     %
% Gobierno de La Rioja                                               %
%                                                                    %
% Juan Luis Varona Malumbres                                         %
% email: jvarona@unirioja.es                                         %
% URL: http://www.unirioja.es/cu/jvarona/                            %
%                                                                    %
% Esto es una clase para LaTeX2e                                     %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DEFINICIONES para Zub\'{\i}a y su formato
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ---------------------- IDENTIFICACION -------------------------------%
\ProvidesFile{zubiaier.cls}[2014/10/06, %
  Clase para la revista Zubia del IER, ver. 1.0]
\typeout{Clase para la revista Zubia del IER, ver. 1.0, <2014/10/06>.}

% ---------------------- CODIGO INICIAL -------------------------------%
% - EN ARTICULOS SIN AUTORES (rese\~nas, ...) NO HAY \contact
% Y NO TIENE QUE QUEJARSE. Lo manejo con opciones:
%\newif\ifautocontact
%    \autocontactfalse
% Para no complicarles la vida si no lo quieren usar as\'{\i}, lo dejo
% como "false" por defecto.

% Defino esto con idea de impedir usar 11pt o 12pt en article 
% (y evitar as\'{\i} componer una art\'{\i}culo con letra mayor), 
% salvo que lo autoricemos expresamente con la opci\'on 
% "eleveneallowed" o "twelveallowed":
\newif\ifelevenallowed
    \elevenallowedfalse
\newif\iftwelveallowed
    \twelveallowedfalse
    
% Para usar letra ``cinzel'' en el t\'itulo (por defecto, "false"):
\newif\ifcinzelintitle
    \cinzelintitlefalse
    
% Para usar letra ``garamond'' en el texto (por defecto, "false"):
\newif\ifgaramond
    \garamondfalse
%% CUIDADO: La letra Garamond hay que instalarla,
%% pues no tiene una licencia ``suficientemente libre''
%% y no est\'a incluida en las distribuciones de TeX.
%% Eso s\'i, la letra est\'a en CTAN

% Para maquetar distinto los art\'iculos introductorios y presentaciones (prefacios):
\newif\ifpreface
    \prefacefalse


% ---------------------- DECLARACION DE OPCIONES ----------------------%

%\DeclareOption{autocontact}{\autocontacttrue}

\DeclareOption{allow11pt}{\elevenallowedtrue}
\DeclareOption{allow12pt}{\twelveallowedtrue}

\newcommand\@ptsizezubiaier{}
\DeclareOption{10pt}{\renewcommand\@ptsizezubiaier{0}}
\DeclareOption{11pt}{\renewcommand\@ptsizezubiaier{1}%
  \PassOptionsToClass{11pt}{article}}
\DeclareOption{12pt}{\renewcommand\@ptsizezubiaier{2}%
  \PassOptionsToClass{12pt}{article}}

\DeclareOption{cinzel}{\cinzelintitletrue}

\DeclareOption{garamond}{\garamondtrue}

\DeclareOption{preface}{\prefacetrue}

% ---------------------- EJECUCION DE OPCIONES ------------------------%
\ProcessOptions
%\ifautocontact%
%   \autocontacttrue%
%\fi

\ifelevenallowed%
\else % La opci\'on "11pt" de article hace \renewcommand\@ptsize{1}
  \if\@ptsizezubiaier1\ClassError{zubiaier}{The option 11pt is forbidden by the zubiaier class.\MessageBreak}%
  {If you actually want to use it, use the options allow11pt and 11pt.}\fi
\fi

\iftwelveallowed%
\else % La opci\'on "12pt" de article hace \renewcommand\@ptsize{2}
  \if\@ptsizezubiaier2\ClassError{zubiaier}{The option 12pt is forbidden by the zubiaier class.\MessageBreak}%
  {If you actually want to use it, use the options allow12pt and 12pt.}\fi
\fi

\ifcinzelintitle%
  \cinzelintitletrue%
\fi

\ifgaramond%
  \garamondtrue%
\fi

\ifpreface%
  \prefacetrue%
\fi

% ---------------------- CARGA LA CLASE ARTICLE -----------------------%

%% IMPORTANTE: La \'unica diferencia esencial para que este archivo 
%% hubiera sido un estilo 
%% (para usar con \documentclass{article} \usepackage{zubiaier})
%% en vez de una clase aut\'onoma
%% (y usarlo como \documentclass{zubiaier}) es esta:
\LoadClass{article}
%% (Aparte de eso, en la clase hay que hacer algo distinto el tratamiento de 10pt y 11pt:
%% - Defino \newcommand\@ptsizezubiaier{} (en article hay un \newcommand\@ptsizezubiaier{}),
%% - Hago los correspondientes \DeclareOption para 10pt, 11pt y 12pt.
%% - Uso \if\@ptsizezubiaier en vez de \if\@ptsize para ver si permito 11pt y 12pt adrede.
%% - En los mensajes de error uso \ClassError en vez \PackageError)

% ---------------------- CODIGO PRINCIPAL -----------------------------%

%% ESTAS COSAS, y el uso de crop, EST\'A AJUSTADO CON LA IMPRENTA
\RequirePackage{geometry}
\geometry{twoside, 
  paperheight = 24.0cm, 
%  paperwidth = 17.0cm, % Lo que realmente interesa
  paperwidth = 17.6cm, % Dejo 0.3 cm m\'as a cada lado para conseguir l\'ineas a sangre al guillotinar
  columnsep = 1.0cm, % Separaci\'on cuando haya dos columnas
  textheight = 19.0cm, 
  textwidth = 11.6cm, % zubia
  centering,
  marginparwidth = 1cm, % S\'olo notas al margen de 1cm; si no, se salen del papel
  top = 2.3cm
}%

%% IMPORTANTE: Todo est\'a pensado para usar pdflatex, no latex.
%% Si se quiere componer con latex, hay que poner
%%    \documentclass[dvips]{zubiaier}
%% para que "zubiaier" le pase el "dvips" a "geometry".
%% De lo contrario, "geometry" no se entera del ancho del
%% papel y se piensa que es el a4 que tiene por defecto.
%% (Este problema no afecta a la caja de texto ni, por
%% tanto, a la paginaci\'on.) 

% Por si queremos indicar que la paginaci\'on es provisional:
\def\p@p{}
\def\provisional{%
  \def\p@p{PP}% % "PP" indica paginaci\'on provisional
}

\ifcinzelintitle\else%
  \provisional%   % <--- Se activa la indicaci\'on de paginaci\'on provisional
\fi
\ifgaramond\else%
  \provisional%   % <--- Se activa la indicaci\'on de paginaci\'on provisional
\fi

\def\journame#1{\def\thejourname{#1}}
\def\yearofpublication#1{\def\theyearofpublication{#1}}
\def\volume#1{\def\thevolume{#1}} 

\journame{Zub\'{\i}a}
\yearofpublication{xxxx}
\volume{xx}

\def\kindofissue#1{\def\thekindofissue{#1}}
\kindofissue{Monogr\'afico}

\def\longjourname#1{\def\thelongjourname{#1}}
% Para que deje espacio en la espacio en la estructura de la cabecera de las primeras
% p\'aginas si no es un monogr\'afico.
\longjourname{\thejourname\phantom{. Monogr\'afico}} 
\def\monographicissue{\longjourname{\thejourname. \thekindofissue}}

\def\cityofjournal#1{\def\thecityofjournal{#1}}
\cityofjournal{Logro\~{n}o}

\def\titlehead#1{\def\thetitlehead{#1}}
\def\authorhead#1{\def\theauthorhead{#1}}

\def\whois#1{\def\@whois{#1}}

%% Sacado de fancyhdr.sty:
%\def\nouppercase#1{\let\uppercase\relax\let\MakeUppercase\relax
%     \expandafter\let\csname MakeUppercase \endcsname\relax#1}

% Avisos por si se olvida poner \titlehead o \authorhead
% (el aviso se pasa autom\'aticamente a may\'usculas,
% pero no merece la pena la complicaci\'on adicional
% que se necesitar\'ia para evitarlo):

\def\titleheadalert{Usa \texttt{\textbackslash titlehead\{T\'itulo o t\'itulo abreviado\}} 
  antes de \texttt{\textbackslash begin\{document\}}}

\titlehead{\titleheadalert}

\def\authorheadalert{Usa \texttt{\textbackslash authorhead\{Lista de autores\}} 
  antes de \texttt{\textbackslash begin\{document\}}}

\authorhead{\authorheadalert}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% GROSOR DE LAS \hline Y LA L\'INEA DE LAS FOOTNOTES
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Por defecto en article es \setlength\arrayrulewidth{.4\p@}
% Pero en la revista Zub\'ia lo quieren de 0.25pt:
%\setlength\arrayrulewidth{0.25\p@}

% Sin el \AtBeginDocument no hace caso:
\AtBeginDocument{\setlength\arrayrulewidth{0.25\p@}}

%\setlength\fboxrule{.4\p@}
\AtBeginDocument{\setlength\fboxrule{0.25\p@}}

% Por defecto en latex.ltx:
%\def\footnoterule{\kern-3\p@
%  \hrule \@width 2in \kern 2.6\p@} % the \hrule is .4pt high
% (Explica \footnoterule en la secci\'on 3.2.2, p. 112, del LaTeX Companion, 2nd ed.)

% Sin el \AtBeginDocument no hace caso:
\AtBeginDocument{\renewcommand{\footnoterule}{\kern-3\p@
 \hrule width 2in height 0.25\p@ \kern 2.6\p@}}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% INFO DE N\'UMERO, QUE SALDR\'A EN TODAS LAS P�GINAS
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\newcommand{\infomonograficooddpage}{%
  \begin{scriptsize}%
  \begin{tabular}{@{}r|l@{}}
  {\bfseries\itshape \thejourname} & {\itshape N\'um.~\thevolume\ (\theyearofpublication), pp.~\pageref{FirstPage}\p@p--\pageref{LastPage}\p@p}\\
  {\bfseries\itshape \thekindofissue} & {\itshape ISSN 1131-5423}
  \end{tabular}%
  \end{scriptsize}%
}

\newcommand{\infomonograficoevenpage}{%
  \begin{scriptsize}%
  \begin{tabular}{@{}r|l@{}}
  {\itshape N\'um.~\thevolume\ (\theyearofpublication), pp.~\pageref{FirstPage}\p@p--\pageref{LastPage}\p@p} & {\bfseries\itshape \thejourname}\\
  {\itshape ISSN 1131-5423} & {\bfseries\itshape \thekindofissue}
  \end{tabular}%
  \end{scriptsize}%
}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Importante: 
% TODO LO RELACIONADO CON LETRAS EN Zub\'ia 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Zub\'ia la vamos a hacer as\'{\i}:

%---------------------------
% \usepackage[T1]{fontenc}
% \usepackage[latin1]{inputenc} % [en caso necesario]
% \usepackage[spanish]{babel}
%---------------------------

%%% Pero prefiero no cargar [T1]{fontenc} ni la tipograf\'ia
%%% en el estilo, pues a mucha gente con distribuciones 
%%% de TeX antiguas les puede dar problemas. En consecuencia,
%%% es mejor cargarlo en cada documento.
%%% En cuanto a [latin1]{inputenc}, no siempre es necesario;
%%% y, adam\'as, existen otros. O sea que mejor no fijarlo 
%%% tampoco en el estilo.

%%% Lo que s\'{\i} fijo en el estilo zubiaier es spanish, pues,
%%% adem\'as, vamos a personalizar aqu\'{\i} algunas cosas.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Importante: 
% TIPOGRAF\'IA cinzel PARA EL T\'ITULO 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Nota: La revista Zub\'ia del IER usa la letra Trajan
%% para los t\�itulos de los art\'iculos. Pero, con LaTeX,
%% \usepackage{trajan}
%% NO TIENE NEGRITAS Y NO FUNCIONAN LOS ACENTOS.
%% As\'i pues, en lugar de trajan voy a usar cinzel,
%% que es bastante parecida.

\ifcinzelintitle
%----- cinzel font -----
%% Parcialmente extra\'ido de cinzel.sty para usar la letra cinzel en type1 con pdftex,
%% y s\'olo en lugares concretos, no en todo el documento:
  \def\cinzelfamily{Cinzel-LF}
  \newcommand*\cinzel{\fontfamily{\cinzelfamily}\def\itshape{\fontfamily{CinzelDecorative-LF}\fontshape{n}\selectfont}\selectfont}
  %\def\rmdefault{\cinzelfamily}
  %\def\itshape{\fontfamily{CinzelDecorative-LF}\fontshape{n}\selectfont}
  \newcommand*\cinzelblack{\fontfamily{\cinzelfamily}\fontseries{k}%
    \def\itshape{\fontfamily{CinzelDecorative-LF}\fontshape{n}\selectfont}\selectfont}
  \newcommand*\cinzelbold{\fontfamily{\cinzelfamily}\fontseries{b}%
    \def\itshape{\fontfamily{CinzelDecorative-LF}\fontshape{n}\selectfont}\selectfont}
%-----------------------
\fi

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%--------------------------------------
% INSTALACI\'ON DE TIPOGRAF\'IA garamond
%%--------------------------------------
%
% Importante (PARA QUE FUNCIONE HAY QUE INSTALARLA EN LA DISTRIBUCI\'ON): 
% LETRA urw garamond Y garamondx PARA EL TEXTO 
%
% PARA QUE FUNCIONE HAY QUE INSTALARLA EN LA DISTRIBUCI\'ON DE TEX
% QUE ESTEMOS USANDO, PUES urw garamond Y garamondx NO TIENEN UNA LICENCIA 
% ``SUFICIENTEMENTE LIBRE'' Y NO EST\'AN INCLUIDAN POR DEFECTO
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\ifgaramond
%%%%% IMPORTANTE:
% LA LETRA SE INSTALA COMO DICE AQU\'I:
% http://tex.stackexchange.com/questions/47491/can-i-install-fonts-from-ctan-using-tex-live-utility
%%-------------------------
%% RESUMEN PARA TEX LIVE:
% You can't use tlmgr (or its front-end TeX Live Utility). 
% There is a script called getnonfreefonts at http://www.tug.org/fonts/getnonfreefonts/ 
% that you have to download with the Terminal command
% 
% curl -O http://tug.org/fonts/getnonfreefonts/install-getnonfreefonts
% and then install with
% 
% sudo texlua install-getnonfreefonts
% Then you can get direction on its use by
%
% getnonfreefonts --help
% For example, in order to install URW Garamond for all users you do
% 
% sudo getnonfreefonts-sys garamond
% Installing fonts for one user only is not recommended.
%%-------------
% MORE COMMANDS:
% getnonfreefonts -l for a list of available fonts:
%arial-urw      Arial (URW)                                  [not installed]
%classico       Classico (URW)                               [not installed]
%dayroman       DayRoman (Apostrophiclabs)                   [not installed]
%eurofont       Euro symbols (Adobe)                         [not installed]
%garamond       GaramondNo8 (URW)                            [not installed]
%garamondx      GaramondNo8 Expert (Michael Sharpe)          [not installed]
%lettergothic   LetterGothic (URW)                           [not installed]
%luximono       LuxiMono (Bigelow & Holmes)                  [not installed]
%vntex-nonfree  VnTeX nonfree (Han The Thanh)                [not installed]
%webomints      Webomints (Galapagos Design Group)           [not installed]
% getnonfreefonts-sys garamondx  ->  to install garamondx (perhaps better with sudo)
% getnonfreefonts-sys -a  ->  to install all nonfree fonts (perhaps better with sudo)
%%-------------
%%----------------------
\RequirePackage[urw-garamond]{mathdesign}
%\RequirePackage{garamondx} % Versalitas verdaderas (sudo getnonfreefonts-sys garamondx)
% Con {garamondx} saca m\'as p\'aginas que sin �garamondx}. Lo evito as\'i:
\RequirePackage[scaled=.985]{garamondx}
%\RequirePackage[scaled=.96]{garamondx} % (Ejemplo de Michael Sharpe)
\else
\RequirePackage[T1]{fontenc}
\RequirePackage{lmodern}
\fi


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% TEXTO EN ESPA\~NOL Y CORTES DE PALABRA EN ESPA\~NOL
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\RequirePackage[english,spanish]{babel}

% (cargo tambi�n ingl�s para el abstract en ingl�s, sobre todo)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% OTROS PAQUETES QUE CARGAMOS SIEMPRE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\RequirePackage{graphicx}
%\usepackage{wrapfig} % <- Si se quiere usar, cargarlo en cada archivo

\RequirePackage{url}
%% Permite usar cosas del estilo
%% \url{http://www.unirioja.es/cu/jvarona/hola.html}
%% y que pueda cortar l\'{\i}neas. Adem\'as, no se fastidian
%% las p\'aginas que tienen una "~" (tilde), 
%% o las direcciones que tienen una "_" (gui\'on bajo).

\RequirePackage{amsmath, amsthm} % (amsmath y amsthm lo uso en este estilo)

% La letra garamond ya incluye todo esto, as\'i que no hay que volverlo a cargar:
\ifgaramond\else
\RequirePackage{amssymb} % <- Aunque no siempre es necesario, lo dejo (incluye \mathbb)
\fi

%%% \allowdisplaybreaks es una orden de amsmath que permite cortes de
%%% p\'agina dentro de una f\'ormula de varias l\'{\i}neas (align, multline, gather, ...)
\allowdisplaybreaks[3] %%% Escala de 1 (permite algo) a 4 (ninguna traba para cortar).
%%% Si en alg\'un sitio queremos impedir un posible corte, usar \\* en vez de \\

\date{} % Por defecto, no ponemos la fecha

%------------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ESPACIADO DEL DOCUMENTO Y ``PENALTIES''
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Sangr\'ia (a una columna, por defecto es 15pt):
\setlength\parindent{20pt}

% Distancia extra entre p\'arrafos):
\parskip=4pt plus 1.5pt minus 1.0pt
% En La Gaceta usaba esto:
% \parskip=0.5pt plus 1.0pt minus 0.5pt % Default: \parskip=0.0pt plus 1.0pt 
% Si en un art\'{\i}culo lo modificamos ligeramente,
% se puede cambiar un poco el aspecto general, haci\'endolo 
% algo m\'as largo o m\'as corto. Eso logra a veces una p\'agina m\'as
% o menos (o que las direcci\'on del autor/autores no queden sueltas en 
% una p\'agina). Y, en la pr\'actica, el cambio de espaciado ni se nota.
%%%%%% -------> IMPORTANTE: Es un truco muy \'util <-------

% A\~NADO UN POCO DE ESPACIO (y bastante glue) ENTRE EL TEXTO
% Y LA L\'INEA DE LAS "footnotes".
% \addtolength{\skip\footins}{1pt plus 5pt minus 1pt}
% (Lo explica en la secci\'on 3.2.2, p. 112, del LaTeX Companion, 2nd ed.)

% Duplico los penalties para l\'{\i}neas viudas y hu\'erfanas,
% pues las que vienen en "latex.ltx" son demasiado permisivas:
\clubpenalty=300 % Default = 150
\widowpenalty=300 % Default = 150
\displaywidowpenalty=150 % Default = 50
% En La Gaceta usaba esto (un aumento de un 50%):
%\clubpenalty=225 % Default = 150
%\widowpenalty=225 % Default = 150
%\displaywidowpenalty=75 % Default = 50



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ASPECTO DE LOS T\'ITULOS DE SECCIONES, SUBSECCIONES, ETC.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% El original de article.cls (lo dejo como est\'a):
%\setcounter{secnumdepth}{3}

%-------------------------
%% Los originales de article.cls:
%\newcommand\section{\@startsection{section}{1}{\z@}%
%    {-3.5ex \@plus -1ex \@minus -.2ex}%
%    {2.3ex \@plus.2ex}%
%    {\normalfont\Large\bfseries}}
%\newcommand\subsection{\@startsection{subsection}{2}{\z@}%
%    {-3.25ex\@plus -1ex \@minus -.2ex}%
%    {1.5ex \@plus .2ex}%
%    {\normalfont\large\bfseries}}
%\newcommand\subsubsection{\@startsection{subsubsection}{3}{\z@}%
%    {-3.25ex\@plus -1ex \@minus -.2ex}%
%    {1.5ex \@plus .2ex}%
%    {\normalfont\normalsize\bfseries}}
%\newcommand\paragraph{\@startsection{paragraph}{4}{\z@}%
%    {3.25ex \@plus1ex \@minus.2ex}%
%    {-1em}%
%    {\normalfont\normalsize\bfseries}}
%\newcommand\subparagraph{\@startsection{subparagraph}{5}{\parindent}%
%    {3.25ex \@plus1ex \@minus .2ex}%
%    {-1em}%
%    {\normalfont\normalsize\bfseries}}
%-------------------------

% Redefiniciones:
\renewcommand\section{\@startsection{section}{1}{\z@}%
    {-3.5ex \@plus -1ex \@minus -.2ex}%
    {2.3ex \@plus.2ex}%
    {\normalfont\bfseries\MakeUppercase}}
\renewcommand\subsection{\@startsection{subsection}{2}{\z@}%
    {-3.25ex\@plus -1ex \@minus -.2ex}%
    {1.5ex \@plus .2ex}%
    {\normalfont\normalsize\bfseries}}
\renewcommand\subsubsection{\@startsection{subsubsection}{3}{\z@}%
    {-3.25ex\@plus -1ex \@minus -.2ex}%
    {1.5ex \@plus .2ex}%
    {\normalfont\normalsize\itshape}}
\renewcommand\paragraph{\@startsection{paragraph}{4}{\z@}%
    {3.25ex \@plus1ex \@minus.2ex}%
    {-1em}%
    {\normalfont\normalsize}}
\renewcommand\subparagraph{\@startsection{subparagraph}{5}{\parindent}%
    {3.25ex \@plus1ex \@minus .2ex}%
    {-1em}%
    {\normalfont\normalsize}}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ABSTRACT
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\def\spanishkeywordsname{Palabras clave}
\def\englishkeywordsname{Key words}

\newcommand{\spanishabstract}{\par\nopagebreak\selectlanguage{spanish}}

\newcommand{\englishabstract}{\par\selectlanguage{english}\em }

\newcommand{\spahishkeywords}[1]{\par\emph{\spanishkeywordsname:}\hspace{0.8em}#1\par
  \vskip 0.5em plus 0.2em\relax\selectlanguage{spanish}}

\newcommand{\englishkeywords}[1]{\par\emph{\englishkeywordsname:}\hspace{0.8em}#1\par
  \vskip 0.5em plus 0.2em\relax\selectlanguage{english}}

%%% Refinici\'on para zubiaier.cls:
\renewenvironment{abstract}{%
  \begin{center}%
  \MakeUppercase\abstractname
  \end{center}%
}
{\vskip 0.5em plus 0.2em\relax\selectlanguage{spanish}}



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ESPACIADO RELACIONADO CON LISTAS E ITEMIZES
% (para hacerlas m\'as compactas)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%% Default: 
%% \itemsep = 4.5pt plus 2.0pt minus 1.0pt (para article con 11pt)
%% \parsep = 4.5pt plus 2.0pt minus 1.0pt (para article con 11pt)
%% Y ambos ser\'{\i}an 4.0pt plus 2.0pt minus 1.0pt para article con 10pt
%%
%% Modificar directamente \itemsep no vale para nada,
%% pues lo repone localmente cada \itemize.
%% Lo que hay que hacer es cambiar \@listi y similares, que est\'an definidos en size10.clo.
\setlength\partopsep{1.5\p@ \@plus 0.75\p@ \@minus 0.75\p@} % Original: 2\p@ \@plus 1\p@ \@minus 1\p@
\def\@listi{\leftmargin\leftmargini
       \parsep 2\p@ \@plus1\p@ \@minus0.75\p@ % Original: 4\p@ \@plus2\p@ \@minus\p@
       \topsep 4.5\p@ \@plus1.5\p@ \@minus2\p@ % Original: 8\p@ \@plus2\p@ \@minus4\p@
       \itemsep2\p@ \@plus1\p@ \@minus0.75\p@} % Original: 4\p@ \@plus2\p@ \@minus\p@
\let\@listI\@listi
\@listi
\def\@listii{\leftmargin\leftmarginii
       \labelwidth\leftmarginii
       \advance\labelwidth-\labelsep
       \topsep    2\p@ \@plus1\p@ \@minus0.75\p@ % Original: 4\p@ \@plus2\p@ \@minus\p@
       \parsep    1.25\p@ \@plus0.75\p@  \@minus0.5\p@ % Original: 2\p@ \@plus\p@  \@minus\p@
       \itemsep   \parsep}
\def\@listiii{\leftmargin\leftmarginiii
       \labelwidth\leftmarginiii
       \advance\labelwidth-\labelsep
       \topsep    1.5\p@ \@plus0.5\p@\@minus0.25\p@ % Original: 2\p@ \@plus\p@\@minus\p@
       \parsep    \z@
       \partopsep \p@ \@plus\z@ \@minus0.25\p@ % Original: \p@ \@plus\z@ \@minus\p@
       \itemsep   \topsep}
% (\@listiv y siguientes no hace falta que los toque, pues no a\~naden separaciones)
% Esto es posible que sirva en alg\'un sitio para algo:
\parsep = 2.0pt plus 1.0pt minus 0.75pt
\topsep = 4.5pt plus 1.5pt minus 2.0pt % default: 8.0pt plus 2.0pt minus 4.0pt
\partopsep = 1.5pt plus 0.75pt minus 0.75pt % default: 2.0pt plus 1.0pt minus 1.0pt
% Por si acaso se usa en alg\'un sitio, dejo tambi\'en este cambio glabal:
\itemsep = 2.0pt plus 1.0pt minus 0.75pt % <--- Creo que modificar esto no vale para nada
% (pero a lo mejor alguien puede usar \itemsep en alg\'un sitio)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% COLOCACI\'ON DE OBJETOS FLOTANTES
% 
% IMPORTANTE: Uso las asignaciones para los "floats" de amsart.cls,
% que son mucho m\'as permisivas que las de article.cls.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
\setcounter{topnumber}{4}
\setcounter{bottomnumber}{4}
\setcounter{totalnumber}{4}
\setcounter{dbltopnumber}{4}
\renewcommand{\topfraction}{.97}
\renewcommand{\bottomfraction}{.97}
\renewcommand{\textfraction}{.03}
\renewcommand{\floatpagefraction}{.9}
\renewcommand{\dbltopfraction}{.97}
\renewcommand{\dblfloatpagefraction}{.9}
\setlength{\floatsep}{12pt plus 6pt minus 4pt}
\setlength{\textfloatsep}{15pt plus 8pt minus 5pt}
\setlength{\intextsep}{12pt plus 6pt minus 4pt}
\setlength{\dblfloatsep}{12pt plus 6pt minus 4pt}
\setlength{\dbltextfloatsep}{15pt plus 8pt minus 5pt}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% TEOREMAS, PROPOSICIONES, DEMOSTRACIONES, ...
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Se usa \usepacage{amsthm}, ya cargado.
% Prefiero dejarlo cargado (en lugar de que
% un usuario lo cargue o no), para que todos
% tengan unificado el estilo.
% Adem\'as, como quiero modificar el tipo de letra 
% de "Teorema" y similares para qeu salga en versalitas,
% me basta hacerlo sobre la definici\'on de amsthm. 

%%% Ejemplos de uso (pero no dejarlo aqu\'{\i} activo)
%\theoremstyle{definition}
%\newtheorem{definicion}{Definici\'on}

%\theoremstyle{plain}
%\newtheorem{lema}[definicion]{Lema}
%\newtheorem{teorema}[definicion]{Teorema}
%\newtheorem{proposicion}[definicion]{Proposici\'on}
%\newtheorem{corolario}[definicion]{Corolario}

%\theoremstyle{remark}
%\newtheorem{nota}[definicion]{Nota}
%\newtheorem{ejemplo}[definicion]{Ejemplo}

%----------------------
%%% PARA PONER "TEOREMA ...", ETC, EN SMALLCAPS.
% Original de amsthm:
% \thm@headfont{\bfseries}
% Redefinici\'on:
\thm@headfont{\scshape}
%----------------------

%----------------------
%%% PARA PONER "PROOF" EN SMALLCAPS
% (sin amsthm, este entorno no existir\'{\i}a)
% Original de amsthm:
%\newenvironment{proof}[1][\proofname]{\par
%  \pushQED{\qed}%
%  \normalfont \topsep6\p@\@plus6\p@\relax
%  \trivlist
%  \item[\hskip\labelsep
%        \itshape
%    #1\@addpunct{.}]\ignorespaces
%}{%
%  \popQED\endtrivlist\@endpefalse
%}
% Redefinici\'on:
\renewenvironment{proof}[1][\proofname]{\par
  \pushQED{\qed}%
  \normalfont \topsep6\p@\@plus6\p@\relax
  \trivlist
  \item[\hskip\labelsep
        \scshape 
    #1\@addpunct{.}]\ignorespaces
}{%
  \popQED\endtrivlist\@endpefalse
}
%----------------------

%----------------------
%%%% Definimos un entorno con espaciado y forma similar a los de los teoremas,
%%%% pero asign\'andole el nombre justo en el momento.
%%%% -----
\def\pseudotheoremfont{\itshape}
\newenvironment{pseudotheorem}[2][]{%
  \thm@indent 
  \pseudotheoremfont 
  \trivlist
  \item[\hskip\labelsep 
       \the\thm@headfont #2\@ifempty{#1}{}{ \normalfont(#1)}\@addpunct{.}] 
       % \@addpunct{.} no pone el . si ya hay
  \ignorespaces
}{%
  \endtrivlist\@endpefalse % <- NO S\'E QU\'E ES ESTO, PERO LO USA amsthm
}
%%%% -----
%----------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% "Captions" CON LETRA \small Y ESTRECHOS
% (Adaptado de la secci\'on 6.5, p. 307, del LaTeX Companion, 2nd ed.)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Redefino el \@makecaption de article.cls.
%% Tambi\'en se podr\'{\i}a haber hecho con el paquete "caption".

% Espacio de margen que voy a usar en los caption habitalmente
% (cuando no estoy en algo m\'as estrecho que la mancha de 
% texto normal, como pudiera ser una columna o una wrapfigure):
\newdimen\captionmargin
\setlength\captionmargin{15pt}

% En sitios estrechos, no dejo margen, salvo que quiera
% forzarlo, y por eso preveo esta variable, por si se
% quiere controlar desde alg\'un archivo .tex:
\newdimen\forcedcaptionmargin
\setlength\forcedcaptionmargin{0pt}

% Eso es lo de article.cls (y est\'a sin cambiar en gaceta.cls).
% \setlength\abovecaptionskip{10\p@}
% \setlength\belowcaptionskip{0\p@}
% Pero en zubiaier.cls prefiero ponerlo un poco m\'as peque\~no:
\setlength\abovecaptionskip{7\p@}


% El \textwidth es fijo.
% El \hsize refleja el ancho del sitio que latex tiene en
% ese momento para escribir (ya sea una columna, una 
% "wrapfigure", etc.)
\long\def\@makecaption#1#2{%
  \vskip\abovecaptionskip
  \ifdim\hsize<\textwidth % <- Puesto JL
    \setlength{\leftskip}{\forcedcaptionmargin}% % <- Puesto JL
    \setlength{\rightskip}{\forcedcaptionmargin}% % <- Puesto JL
  \else % <- Puesto JL
    \setlength{\leftskip}{\captionmargin}% % <- Puesto JL
    \setlength{\rightskip}{\captionmargin}% % <- Puesto JL  
  \fi % <- Puesto JL
  \sbox\@tempboxa{\small #1: #2}%
  \ifdim \wd\@tempboxa >\hsize 
    \small #1: #2\par
  \else
    \global \@minipagefalse
    \hb@xt@\hsize{\hfil\box\@tempboxa\hfil}% 
  \fi
  \vskip\belowcaptionskip}

%% Defino un \pseudocaption, que modo sea como el \caption (con el mismo
%% y el tipo de letra pero sin poner "Figura" (o "Cuadro") y el n\'umero.

% Adaptado del \caption (que llama a \@caption) de latex.ltx.
% El \begingroup-\endgroup sirve para para hacer el cambio de anchura local.
% El \nobreak lo pongo por si el \psudocaption se usa, no en un "figure" 
% o "table", sino simplemente en un "\begin{center}-\end{center}"
% (aunque es posible que lo de los "minipage" que salen por en estas
% definiciones ya impidan esa posibldad, no s\'e...).
\def\pseudocaption#1{\par\nobreak\begingroup\@parboxrestore
    \if@minipage
      \@setminipage
    \fi\@makepseudocaption{#1}\endgroup}

\long\def\@makepseudocaption#1{%
  \vskip\abovecaptionskip
  \ifdim\hsize<\textwidth % <- Puesto JL
    \setlength{\leftskip}{\forcedcaptionmargin}% % <- Puesto JL
    \setlength{\rightskip}{\forcedcaptionmargin}% % <- Puesto JL
  \else % <- Puesto JL
    \setlength{\leftskip}{\captionmargin}% % <- Puesto JL
    \setlength{\rightskip}{\captionmargin}% % <- Puesto JL  
  \fi % <- Puesto JL
  \sbox\@tempboxa{\small #1}%
  \ifdim \wd\@tempboxa >\hsize
    \small #1\par 
  \else
    \global \@minipagefalse
    \hb@xt@\hsize{\hfil\box\@tempboxa\hfil}%
  \fi%
  \vskip\belowcaptionskip}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% LA DIRECCI\'ON, EMAIL Y P\'AGINA WEB
% DEL AUTOR (O AUTORES) AL FINAL DEL DOCUMENTO
% LO PONO EN UNA TABLA EN LA PARTE DE ABAJO
% DE LA PRIMERA P\'AGINA
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\def\emailname{Correo electr\'onico}
\def\webname{P\'agina web}

%% SINTAXIS (\'usense tantos de estos como autores haya):
%\infofor{1}{direcci\'on autor 1}{email autor 1}{p\'agina web autor 1}
%\infofor{2}{direcci\'on autor 2}{email autor 2}{p\'agina web autor 2}
%\infofor{}{Informaci\'on adicional}{}{}
%\moreinfo{Informaci\'on adicional}


%\newcommand{\infofor}[4]{%
%      \ifx\empty #1\else#1\@addpunct{.}\fi & #2\\ \ifx\empty #3\else & \normalfont\emailname: \contacturl{#3}\\\fi
%      \ifx\empty #4\else & \normalfont\webname: \contacturl{#4}\\\fi 
%  }

%% Una alternativa:

%\newcommand{\infofor}[4]{%
%      \ifx\empty #1\else#1\@addpunct{.}\fi & #2\\ \ifx\empty #3\else 
%        & \normalfont\emailname: \parbox[t]{0.75\textwidth}{\raggedright\texttt{#3}}\\\fi
%      \ifx\empty #4\else & \normalfont\webname: \url{#4}\\\fi 
%  }

%% Mejor as\'i:

\newcommand{\infofor}[4]{%
      \ifx\empty #1\else#1\@addpunct{.}\fi & #2\\ \ifx\empty #3\else 
        & \parbox{0.94\textwidth}{\raggedright\normalfont\emailname:\enspace \texttt{#3}}\\\fi
      \ifx\empty #4\else & \normalfont\webname:\enspace \url{#4}\\\fi 
  }

\newcommand{\moreinfo}[1]{%
      \infofor{}{#1}{}{}%
  }
  
\def\thelistofinfos{} % Para poder chequear en \@maketitle si hemos puesto ``infos''

\newcommand{\listofinfos}[1]{%
  \long\def\thelistofinfos{#1}}

\newcommand{\printinfo}{%
\begin{table}[!b]%
%\sloppy
\begin{scriptsize}%
\rule{\textwidth}{0.25pt}\par\smallskip
% \textwidth es 11.6cm 
\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}rp{0.94\textwidth}@{}} % Con 0.95\textwidth da overfull
\thelistofinfos
\end{tabular*}\par
\end{scriptsize}%
\end{table}}

% MEJOR AS\'I:

\renewcommand{\printinfo}{%
\begin{table}[!b]
%\sloppy
\begin{scriptsize}%
\rule{\textwidth}{0.25pt}\par\smallskip
% \textwidth es 11.6cm 
\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}r@{}p{0.96\textwidth}@{}} 
\thelistofinfos
\end{tabular*}\par
\end{scriptsize}%
\end{table}}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MANEJO DE LAS CABECERAS
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% PARA LAS CABECERAS DE Zub\'ia VOY A USAR fancyhdr.sty

\usepackage{color}
%  \definecolor{black}{gray}{0}
\definecolor{blanco}{gray}{1}
\definecolor{greyfordata}{gray}{0.66}

%% En lugar de en las cabeceras, lo pondr\'e en el t\'itulo:
\newcommand{\rulewithdata}{%
\textcolor{greyfordata}{\rule[-4pt]{\textwidth}{13pt}}\hspace{-\textwidth}%
  \bfseries\small
  \textcolor{white}{\;\;\thelongjourname\hfill
  \thevolume\hfill
  \pageref{FirstPage}\p@p--\pageref{LastPage}\p@p\hfill 
  \thecityofjournal\hfill
  \theyearofpublication\;\;}%
}

\usepackage{fancyhdr}
% First re-define the plain page style that will be used on the title page
\fancypagestyle{plain}{%
\renewcommand{\headrulewidth}{0.0pt}
\fancyhf{} % clear all header and footer fields
\fancyfoot[LO]{}
%\fancyfoot[RO]{{\small\thepage}\hspace{-5mm}\rule[10pt]{18mm}{0.25pt}\hspace{-27mm}} % si no se gillotinara
\fancyfoot[RO]{{\small\thepage}\hspace{-5mm}\rule[10pt]{21mm}{0.25pt}\hspace{-30mm}} % 3mm se gillotinar\'an
%\fancyfoot[LE]{\hspace{-27mm}\rule[10pt]{18mm}{0.25pt}\hspace{-5mm}{\small\thepage}} % si no se gillotinara
\fancyfoot[LE]{\hspace{-30mm}\rule[10pt]{21mm}{0.25pt}\hspace{-5mm}{\small\thepage}} % 3mm se gillotinar\'an
\fancyfoot[RE]{}
}
% First re-define the plain page style that will be used on the title page
\fancypagestyle{firstpage}{%
\renewcommand{\headrulewidth}{0.0pt}
\fancyhf{} % clear all header and footer fields
%\fancyhead[C]{\textcolor{greyfordata}{\rule[-4pt]{\textwidth}{13pt}}\hspace{-\textwidth}%
%  \bfseries\small
%  \textcolor{white}{\;\;\thelongjourname\hfill
%  \thevolume\hfill
%  \pageref{FirstPage}\p@p--\pageref{LastPage}\p@p\hfill 
%  \thecityofjournal\hfill
%  \theyearofpublication\;\;}}
\fancyhead[C]{} % Mejor que \fancyhead[C]{\rulewithdata}, pues \rulewithdata lo incorporo al t\'itulo
\fancyfoot[LO]{}
%\fancyfoot[RO]{{\small\thepage}\hspace*{-5mm}\rule[10pt]{18mm}{0.25pt}\hspace*{-27mm}}
%\fancyfoot[RO]{\hspace{0mm}\rlap{\hspace{2mm}\small\thepage}\rule[10pt]{18mm}{0.25pt}\hspace{-27mm}} % si no se gillotinara
\fancyfoot[RO]{\hspace{0mm}\rlap{\hspace{2mm}\small\thepage}\rule[10pt]{21mm}{0.25pt}\hspace{-30mm}} % 3mm se gillotinar\'an
%\fancyfoot[LE]{\hspace*{-27mm}\rule[10pt]{18mm}{0.25pt}\hspace{-5mm}{\small\thepage}}
%\fancyfoot[LE]{\hspace{-27mm}\rule[10pt]{18mm}{0.25pt}\llap{\small\thepage\hspace{2mm}}\hspace{0mm}} % si no se gillotinara
\fancyfoot[LE]{\hspace{-30mm}\rule[10pt]{21mm}{0.25pt}\llap{\small\thepage\hspace{2mm}}\hspace{0mm}} % 3mm se gillotinar\'an
\fancyfoot[RE]{}
}
\pagestyle{fancy} 
\fancyhead[LO]{}
\fancyhead[RO]{\footnotesize \MakeUppercase\thetitlehead}
\fancyhead[LE]{\footnotesize \MakeUppercase\theauthorhead}
\fancyhead[RE]{}
\renewcommand{\headrulewidth}{0.25pt}
\fancyfoot[C]{}
\fancyfoot[LO]{\infomonograficooddpage}
%\fancyfoot[RO]{{\small\thepage}\hspace*{-5mm}\rule[10pt]{18mm}{0.25pt}\hspace*{-27mm}}
%\fancyfoot[RO]{\hspace{0mm}\rlap{\hspace{2mm}\small\thepage}\rule[10pt]{18mm}{0.25pt}\hspace{-27mm}} % si no se gillotinara
\fancyfoot[RO]{\hspace{0mm}\rlap{\hspace{2mm}\small\thepage}\rule[10pt]{21mm}{0.25pt}\hspace{-30mm}} % 3mm se gillotinar\'an
%\fancyfoot[LE]{\hspace*{-27mm}\rule[10pt]{18mm}{0.25pt}\hspace{-5mm}{\small\thepage}}
%\fancyfoot[LE]{\hspace{-27mm}\rule[10pt]{18mm}{0.25pt}\llap{\small\thepage\hspace{2mm}}\hspace{0mm}} % si no se gillotinara
\fancyfoot[LE]{\hspace{-30mm}\rule[10pt]{21mm}{0.25pt}\llap{\small\thepage\hspace{2mm}}\hspace{0mm}} % 3mm se gillotinar\'an
\fancyfoot[RE]{\infomonograficoevenpage}

\ifpreface % En las p\'aginas de los prefacios no hay cabeceras
\pagestyle{fancy} 
\fancyhead[LO]{}
\fancyhead[RO]{}
\fancyhead[LE]{}
\fancyhead[RE]{}
\renewcommand{\headrulewidth}{0pt}
\fancyfoot[C]{}
\fancyfoot[LO]{\infomonograficooddpage}
%\fancyfoot[RO]{{\small\thepage}\hspace*{-5mm}\rule[10pt]{18mm}{0.25pt}\hspace*{-27mm}}
%\fancyfoot[RO]{\hspace{0mm}\rlap{\hspace{2mm}\small\thepage}\rule[10pt]{18mm}{0.25pt}\hspace{-27mm}} % si no se gillotinara
\fancyfoot[RO]{\hspace{0mm}\rlap{\hspace{2mm}\small\thepage}\rule[10pt]{21mm}{0.25pt}\hspace{-30mm}} % 3mm se gillotinar\'an
%\fancyfoot[LE]{\hspace*{-27mm}\rule[10pt]{18mm}{0.25pt}\hspace{-5mm}{\small\thepage}}
%\fancyfoot[LE]{\hspace{-27mm}\rule[10pt]{18mm}{0.25pt}\llap{\small\thepage\hspace{2mm}}\hspace{0mm}} % si no se gillotinara
\fancyfoot[LE]{\hspace{-30mm}\rule[10pt]{21mm}{0.25pt}\llap{\small\thepage\hspace{2mm}}\hspace{0mm}} % 3mm se gillotinar\'an
\fancyfoot[RE]{\infomonograficoevenpage}
\fi

%% Puede haber hasta tres l\'{\i}neas de cabecera (si hay muchos autores),
%% as\'{\i} que tengo que aumentar el \headheight=12pt que viene por defecto:
\headheight=30pt
%% SIN ESO, OBTENGO ESTE MENSAJE:
%Package Fancyhdr Warning: \headheight is too small (12.0pt): 
% Make it at least 29.22601pt.
% We now make it that large for the rest of the document.
% This may cause the page layout to be inconsistent, however.
%% En la pr\'actica, lo que ocurre\'{\i}a es que, a partir de 
%% la primera cabecera que no cabe en los 12pt, la cabecera se 
%% hac\'{\i}a m\'as grande y todo se desplazaba hacia abajo, 
%% incluido el foot y su ---- sobre el n\'umero de p\'agina.

%----------------------


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% T\'ITULOS DE LOS ART\'ICULOS Y DE LOS PREFACIOS
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------
% T\'ITULOS: Modificaci\'on de lo de article.
%--------------------------------------------------

% --------------------
% T\'itulos habituales
% --------------------

%%% Esto es lo de article.cls (sin titlepage) con \thispagestyle adaptado a zubiaier:
\renewcommand\maketitle{\par
  \begingroup
    \renewcommand\thefootnote{\@fnsymbol\c@footnote}%
    \def\@makefnmark{\rlap{\@textsuperscript{\normalfont\@thefnmark}}}%
    \long\def\@makefntext##1{\parindent 1em\noindent
            \hb@xt@1.8em{%
                \hss\@textsuperscript{\normalfont\@thefnmark}}##1}%
    \if@twocolumn
      \ifnum \col@number=\@ne
        \@maketitle
      \else
        \twocolumn[\@maketitle]%
      \fi
    \else
      \newpage
      \global\@topnum\z@   % Prevents figures from going at top of page.
      \@maketitle
    \fi
    %\thispagestyle{plain}\@thanks
    \thispagestyle{firstpage}\@thanks
  \endgroup
  \setcounter{footnote}{0}%
  \global\let\thanks\relax
  \global\let\maketitle\relax
  \global\let\@maketitle\relax
  \global\let\@thanks\@empty
  \global\let\@author\@empty
  \global\let\@date\@empty
  \global\let\@title\@empty
  \global\let\title\relax
  \global\let\author\relax
  \global\let\date\relax
  \global\let\and\relax
}
% Lo de article.cls (sin titlepage):
\def\@maketitle{%
  \newpage
  \null
  \vskip 2em%
  \begin{center}%
  \let \footnote \thanks
    {\LARGE \@title \par}% 
    \vskip 1.5em%
    {\large
      \lineskip .5em%
      \begin{tabular}[t]{c}%
        \@author
      \end{tabular}\par}%
    \vskip 1em%
    {\large \@date}%
  \end{center}%
  \par
  \vskip 1.5em}
% Adaptado para zubiaier:
\def\@maketitle{%
  \newpage
    \label{FirstPage}% <<<<< PUESTO JL
  \begin{center}%
      \rulewithdata% <<<<< PUESTO JL
  \end{center}%
  \vskip 2.5em%
  \begin{raggedright}%
  \let \footnote \thanks
    \ifcinzelintitle
    {\large\cinzelbold \uppercase\expandafter{\@title}\par}%
%    {\cinzelbold \uppercase\expandafter{\@title}\par}%
%    {\Large\cinzelbold \@title \par}%
    \else
    {\large\bfseries \uppercase\expandafter{\@title}\par}%
    \fi
  \end{raggedright}%
    \vskip 1.5em%
  \begin{raggedleft}
    {\scriptsize\bfseries
      \baselineskip 0.5em%
      \lineskip 0.5em%
%      \begin{tabular}[t]{r@{}}%
        \uppercase\expandafter{\@author}%
%      \end{tabular}%
    \par}%
    \vskip 1em%
  \end{raggedleft}%
  \begin{center}%
      {\large \@date}%
  \end{center}%
  \par
  \ifx\empty\thelistofinfos\else\printinfo\fi
  \vskip 1.5em}

%% Sacado de fancyhdr.sty:
%\def\nouppercase#1{\let\uppercase\relax\let\MakeUppercase\relax
%     \expandafter\let\csname MakeUppercase \endcsname\relax#1}
%

% NOTA: EL #1 SE VE AFECTADO POR EL \uppercase,
% PERO COMO AH\'I SOLO HAY QUE PONER 1, 2, 3...,
% AL PASARLO A MAY�SCULAS NO SE VE AFECTADO.
\newcommand{\info}[1]{\textsuperscript{#1}}


% --------------------
% T\'itulos para prefacios
% --------------------

\ifpreface
  \def\@maketitle{\@makeprefacetitle}
\fi

%% Lo de article.cls (sin titlepage):
%\def\@maketitle{%
%  \newpage
%  \null
%  \vskip 2em%
%  \begin{center}%
%  \let \footnote \thanks
%    {\LARGE \@title \par}% 
%    \vskip 1.5em%
%    {\large
%      \lineskip .5em%
%      \begin{tabular}[t]{c}%
%        \@author
%      \end{tabular}\par}%
%    \vskip 1em%
%    {\large \@date}%
%  \end{center}%
%  \par
%  \vskip 1.5em}
% Adaptado para zubiaier:
\def\@makeprefacetitle{%
  \newpage
    \label{FirstPage}% <<<<< PUESTO JL
%  \begin{center}%
%      \rulewithdata% <<<<< PUESTO JL
%  \end{center}%
  \vskip 2.5em%
  \begin{raggedright}%
  \let \footnote \thanks
    \ifcinzelintitle
    {\Large\cinzelbold \uppercase\expandafter{\@title}\par}%
%    {\cinzelbold \uppercase\expandafter{\@title}\par}%
%    {\Large\cinzelbold \@title \par}%
    \else
    {\Large\bfseries \uppercase\expandafter{\@title}\par}%
    \fi
  \end{raggedright}%
    \vskip 1.5em%
  \begin{raggedright}
    {\large\bfseries
      \lineskip 0.5em%
%      \begin{tabular}[t]{c}%
        \@author%
%      \end{tabular}%
    \par}%
    \vskip 0.5em%
  \end{raggedright}%
  \begin{raggedright}
    {\normalsize\itshape
      \lineskip 0.5em%
%      \begin{tabular}[t]{c}%
        \@whois%
%      \end{tabular}%
    \par}%
    \vskip 1em%
  \end{raggedright}%
  \begin{center}%
      {\large \@date}%
  \end{center}%
  \par
  \ifx\empty\thelistofinfos\else\printinfo\fi % Lo normal es que no haya
  \vskip 3.5em}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% BIBLIOGRAF\'IA
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------
% PARA QUE EN LA BIBLIOGRAF\'IA NO HAYA TANTO ESPACIO 
% DE SEPARACI\'ON ENTRE LOS \bibitem
%--------------------------------------------------

\renewcommand\@openbib@code{\parsep \z@}
%% Eso est\'a adaptado del \DeclareOption{openbib}
%% de article.cls 
% (se puede anular con \let\@openbib@code\@empty)

%--------------------------------------------------
% PARA, CUANDO LAS CITAS BIBLIOGR\'AFICAS NO SE HACEN CON \bibitem Y \cite,
% SINO DE FORMA MANUAL, ESCRIBIR LA BIBLIOGRAF\'IA CON SANGR\'IA FRANCESA,
% SIN QUE APAREZCA NUMERACI\'ON O ETIQUETAS QUE NO SE VAN A USAR.
% Esto es muy adecuado si las citas se hacen como (Autor, a\~no)
% o similar.
%%% (Puesto que numerar no vale para nada [no se cita as\'{\i}], esto
%%% queda bastante bien, y yo creo que es muy adecuado.)
%--------------------------------------------------

% Original de article.cls:
%\newenvironment{thebibliography}[1]
%     {\section*{\refname}%
%      \@mkboth{\MakeUppercase\refname}{\MakeUppercase\refname}%
%      \list{\@biblabel{\@arabic\c@enumiv}}%
%           {\settowidth\labelwidth{\@biblabel{#1}}%
%            \leftmargin\labelwidth
%            \advance\leftmargin\labelsep
%            \@openbib@code
%            \usecounter{enumiv}%
%            \let\p@enumiv\@empty
%            \renewcommand\theenumiv{\@arabic\c@enumiv}}%
%      \sloppy
%      \clubpenalty4000
%      \@clubpenalty \clubpenalty
%      \widowpenalty4000%
%      \sfcode`\.\@m}
%     {\def\@noitemerr
%       {\@latex@warning{Empty `thebibliography' environment}}%
%      \endlist}




%%% As\'{\i} se hacen las sangr\'{\i}as francesas:
% \begin{list}{}{%
%   \setlength{\leftmargin}{1pc}%
%   \setlength{\itemindent}{-1pc}%
%   \setlength{\listparindent}{-1pc}%
%   \setlength{\topsep}{0pt}}
% 
% \item ...
% 
% \item ...
% \end{list}

%%% Nuevo entorno "thebibliography*" que combina las ideas anteriores:
\newenvironment{thebibliography*}
     {\section*{\refname}%
      \@mkboth{\MakeUppercase\refname}{\MakeUppercase\refname}%
      \list{}%
           {\setlength{\leftmargin}{1pc}%
            \setlength{\itemindent}{-1pc}
            \setlength{\listparindent}{-1pc}
            \setlength{\topsep}{0pt}
            \@openbib@code}%
      \sloppy
      \clubpenalty4000
      \@clubpenalty \clubpenalty
      \widowpenalty4000%
      \sfcode`\.\@m}
     {\def\@noitemerr
       {\@latex@warning{Empty `thebibliography*' environment}}%
      \endlist}
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% REDEFINICI\'ON DE \begin{document} Y \end{document}
% PARA CARGAR ALGUNA COSA AUTOM\'ATICAMENTE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Redefine \begin{document} and \end{document}
% in order to include begin and end matter automatically.
% The original environment is still available as origdocument.
%---
% En principio, as\'{\i} se redefinir\'{\i}a el \document:
% \let\origdocument\document   
% \def\document{\origdocument........} 
% donde en ........ se pone lo que se desee.
% AS\'I, PODR\'IAMOS HACER
%\let\origdocument\document 
%\def\document{\label{FirstPage}\origdocument}
% PERO ESE \label{FirstPage} DA ERRORES, SOBRE TODO
% EN COMBINACI\'ON CON \usepackage{hyperref}
%---
% Y as\'{\i} se hace con \enddocument:
\let\endorigdocument\enddocument
\def\enddocument{\enlargethispage{2mm}\label{LastPage}\endorigdocument} % 
%\def\enddocument{\enlargethispage{2mm}\makelastpage\label{LastPage}\endorigdocument} % 
%% El mecanismo del paquete "lastpage" para poner una etiqueta al final 
%% del documento (y poder saber el n\'umero de la \'ultima p\'agina) 
%% es algo mejor, pues tiene en cuenta los posibles objetos flotantes 
%% que queden despu\'es del texto final.
%% Pero como eso no hay que permitirlo (aunque sea "a mano"), no merece la
%% pena complicarse la vida.

%% A veces puede suceder que justo tras el \makelastpage haya un cambio
%% de p\'agina, y que entonces el \label{LastPage} caiga en una p\'agina
%% que no existe, con lo cual el m\'etodo autom\'atico de saber el
%% n\'umero de la \'ultima p\'agina no funciona. Se puede arreglar poni\'endolo
%% manual con \finalpage{} o usando \enlargethispage{2mm} o similar.
%% Como lo de \enlargethispage{2mm} es muy razonable, lo dejo fijo
%% en la definici\'on de \enddocument.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% COSAS DE SPANISH PARA QUE SE CARGUEN DESPU\'ES DEL BEGIN DOCUMENT
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Lo que hace spanish (dentro de \layoutspanish, por eso el ##1):
%  \def\@fnsymbol##1%
%    {\ifcase##1\or*\or**\or***\or****\or
%     *****\or******\else\@ctrerr\fi}%

%%% Lo que hace latex.ltx:
%\def\@fnsymbol#1{\ensuremath{\ifcase#1\or *\or \dagger\or \ddagger\or
%   \mathsection\or \mathparagraph\or \|\or **\or \dagger\dagger
%   \or \ddagger\ddagger \else\@ctrerr\fi}}
% \def\fnsymbol#1{\expandafter\@fnsymbol\csname c@#1\endcsname} % latex.ltx

% Repongo la original inglesa (en latex.ltx):
\addto\layoutspanish{\def\@fnsymbol#1{%
   \ensuremath{\ifcase#1\or *\or \dagger\or \ddagger\or
   \mathsection\or \mathparagraph\or \|\or **\or \dagger\dagger
   \or \ddagger\ddagger \else\@ctrerr\fi}}}

%\shorthandoff{"} % <= HAY QUE PONERLO DESPUES DEL \begin{document}, NO ANTES.
%%% Es de babel, no de spanish.
%
%\renewcommand\shorthandsspanish{}
% es una variante optimizada de esto:
%\addto\shorthandsspanish{\spanishdeactivate{."'~<>}}
% Pero, al menos de momento, no quiero cargarme <<...>>, 
% ni tampoco ~---, luego lo dejo as\'{\i}:
\addto\shorthandsspanish{\spanishdeactivate{"}\shorthandoff{"}}
% (Si me cargara ~---, podr\'{\i}a usar \nobreakdashes---; el comando 
% \nobreakdashes exist\'{\i}a en amsmath, y que fue a\~nadido a LaTeX en 2003.)
% Para evitar que ~n no sea \~n en spanish, uso esto:
\deactivatetilden % Para que ~n no sea \~n en spanish
% La ' esta desactivada por defecto (desde hace muchos "spanish"), 
% luego no hace falta quitarla.
%%% El punto decimal lo dejo como est\'a por defecto en spanish;
%%% si quiere, cada usuario (o editor) lo puede controlar en su 
%%% art\'{\i}culo (con \decimalpoint, por ejemplo).

%%%%% OLVIDO DE SPANISH 4.1:
\providecommand{\es@op@i}{\es@op@ac i} % <--- En spanish 5, \es@op@i ya no existe
\addto\es@operators{% (Estos %, aqu\'{\i} y luego, son importantes)
  \def\inf{\mathop{\operator@font \protect\es@op@i nf}}%
}%

%%%%% EL \pmod DE LA AMS (EN amsmath.sty) DEJA MENOS ESPACIO
%%%%% DENTRO DE TEXTO NORMAL. SPANISH LO MACHACA CUANDO
%%%%% REDEFINE \pmod PARA PONERLE EL ACENTO, PUES USA LA VERSI\'ON
%%%%% DE LaTeX ORDINARIO. AS\'I PUES, HAY QUE REDEFINIRLO
%%%%% SI QUEREMOS QUE ACT\'UE COMO EL DE LA AMS.
%%%%% SE HACE COMO SIGUE (El \addto\es@operators es para postergar su carga,
%%%%% pues las definiciones de spanish toman efecto cuando aparece
%%%%% el \begin{document}; sin el \addto\es@operators, esta definici\'on
%%%%% habr\'{\i}a que darla despu\'es del \begin{document}).
%% ---- Parte recordatoria de lo que hay en amsmath:
%\newcommand{\pod}[1]{\allowbreak
%  \if@display\mkern18mu\else\mkern8mu\fi(#1)}
%% ---- fin de la parte recordatoria.
%\makeatletter%
%\addto\es@operators{% (Estos % son importantes)
%  \renewcommand{\pmod}[1]{\pod{{\operator@font m\es@op@ac od}\mkern6mu#1}}%
%}%
%\makeatother
%%%%% Pero yo prefiero esto:
\addto\es@operators{% (Estos % son importantes)
  \renewcommand{\pmod}[1]{%
  \allowbreak\mkern8mu({\operator@font m\es@op@ac od}\mkern6mu#1)}%
}%
%%%%% que es parecido al original de LaTeX:
%%%%% \def\pmod#1{%
%%%%%  \allowbreak\mkern18mu({\operator@font mod}\,\,#1)}
%%%%% }
%%%%% pero con menos espacio (siempre el peque\~no de amsmath).
%
%%%% Adem\'as, redefino el \mod de amsmath (cargado en este estilo) 
%%%% para ponerle el acento, pues spanish v4.2 no lo hace:
%% ---- Parte recordatoria de lo que hay en amsmath:
%\newcommand{\mod}[1]{\allowbreak\if@display\mkern18mu
%  \else\mkern12mu\fi{\operator@font mod}\,\,#1}
%% ---- fin de la parte recordatoria.
\addto\es@operators{% (Estos % son importantes)
  % Para recuperar el mod no acentuado fuera de spanish,
  % con spanish v4.2 necesito aqu\'{\i} un \babel@save\mod.
  % Por el contrario, con spanish v5.0, el mismo \babel@save 
  % hace que el no acentuado no se recupere fuera de spanish.
  % He optado por que funcione bien con la versi\'on 5.
  \renewcommand{\mod}[1]{\allowbreak\if@display\mkern18mu
  \else\mkern12mu\fi{\operator@font m\es@op@ac od}\,\,#1}%
}

%%%% Finalmente, por si no estoy usando spanish,
%%%% redefino \pmod y \mod para que tengan el
%%%% mismo espaciado que los anteriores
%%%% (pero sin el acento en la o, claro)
\renewcommand{\pmod}[1]{%
  \allowbreak\mkern8mu({\operator@font mod}\mkern6mu#1)}%
\renewcommand{\mod}[1]{\allowbreak\if@display\mkern18mu
  \else\mkern12mu\fi{\operator@font mod}\,\,#1}%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
\endinput 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

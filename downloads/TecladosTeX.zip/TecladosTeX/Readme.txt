    TWO KEYBOARD LAYOUTS ADAPTED TO WRITE TeX/LaTeX
    (Juan L. Varona, 2004/9/21, under license GPL of GNU)

The two files
   TeX-7bits-spanish.keylayout
and
   TeX-8bits-spanish.keylayout
are two keyboard layouts whose object is to simplify theprocess of writting TeX/LaTeX in any application underMac OS X (version 10.2 or later; they do not work with 10.1).

For more details, read the file TeXkeylayout.html included in this
distribution; it is a copy of the web page
http://www.unirioja.es/dptos/dmc/jvarona/TeXkeylayout.html

All these files are distributed under license GPL of GNU:http://www.gnu.org

Enjoy it!

Juan L. Varona

--

Juan L. Varona
Department of Mathematics and Computation
University of La Rioja
26004 Logro�o
Spain

jvarona@dmc.unirioja.es
http://www.unirioja.es/dptos/dmc/jvarona/tex.html
http://www.unirioja.es/dptos/dmc/jvarona/welcome.html
http://www.unirioja.es/dptos/dmc/jvarona/hola.html


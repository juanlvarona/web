%%
%% Este es el fichero 'semacedya.cls'
%%
\NeedsTeXFormat{LaTeX2e}[1995/12/01] \ProvidesClass{semacedya}
              [2007/06/28 v0.9a
 Clase basada en article con modificaciones para el boletin de la SeMA]
\LoadClass[twoside]{article} \RequirePackage{graphicx}
\RequirePackage{epsfig} \RequirePackage{wrapfig}
\RequirePackage{amssymb} \RequirePackage{amsmath}
\RequirePackage{amsfonts}
\RequirePackage{fancyhdr} %Tal vez alguna distribucion de TeX no lo traiga
\RequirePackage{ifthen} \RequirePackage{color}
\RequirePackage[latin1]{inputenc}
\RequirePackage[official,right]{eurosym}
\RequirePackage[french,spanish,english]{babel}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                    %
%                   DIMENSIONES                      %
%                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
\paperwidth=17cm \paperheight=24cm \textwidth=12.1cm
\setlength{\hoffset}{-1in} \oddsidemargin=2.4cm
\evensidemargin=2.4cm \setlength{\voffset}{-1in} \topmargin=1.6cm


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Para evitar los overfull a toda costa     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
\pretolerance=9000 \tolerance=9000


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sacado del paquete lastpage                  %
%Averigua el n�mero de p�ginas del articulo   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\def\lastpage@putlabel{\addtocounter{page}{-1}%
   \immediate\write\@auxout{\string
   \newlabel{LastPage}{{}{\thepage}}}%
   \addtocounter{page}{1}}
\AtEndDocument{%
   \message{AED: lastpage setting LastPage}%
   \clearpage\lastpage@putlabel}%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definici�n de los comandos address y email para especificar     %
% la direcci�n y el email del autor al hacer maketitle            %
%                                                                 %
% Redefinici�n (sencilla) de maketitle                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\def\address#1{\def\@address{#1}}
\let\@address\@empty

\def\email#1{\def\@email{#1}}
\let\@email\@empty

\renewcommand\maketitle{\par
  \begingroup
    \renewcommand{\thefootnote}{\fnsymbol{footnote}}%
    \def\@makefnmark{\hbox to\z@{$\m@th^{\@thefnmark}$\hss}}%
    \long\def\@makefntext##1{\parindent 1em\noindent
            \hbox to1.8em{\hss$\m@th^{\@thefnmark}$}##1}%
      \global\@topnum\z@   % Prevents figures from going at top of page.
      \@maketitle
    \thispagestyle{fancy}
%  \endgroup
% a�adimos la informacion del articulo al sumario
\setcounter{footnote}{0}%
  \let\maketitle\relax\let\@maketitle\relax
  \gdef\@author{}\gdef\@title{}
\endgroup

}

\def\@maketitle{%
  \null
  \begin{center}%
    {\bfseries\@ucnothanks\@title\par}%
    \vskip .075in%
    {\footnotesize
      \spaceskip=1.5\fontdimen2\the\font
      \def\and{\ \scriptsize AND }
      \@tempswafalse\expandafter\@doauth\@author\and\relax}%
  \vskip 1em%
    {\small\@address}%  %Cambiado date por address
    \vskip .5em%
    {\small\tt \@email}%  %A~nadiendo email
    \vskip 1em%
  \end{center}%
  \par
  \vskip .1in}
\def\@ucnothanks#1{\expandafter\@ucnt#1\thanks\relax}
\def\@ucnt#1\thanks{\uppercase{#1}\futurelet\@tempa\@ucnta}
\def\@ucnta{\ifx\@tempa\relax\else\@ucntb\fi}
\def\@ucntb#1\thanks\relax{\thanks{#1}}
\def\@doauth#1\and{\let\@nextdoa=\@doauth
 \def\@tempc{\@ucnothanks{#1}}
 \futurelet\@tempa\@doautha}
\def\@doautha{\ifx\@tempa\relax
  \if@tempswa {\and}\fi
  \let\@nextdoa=\relax
 \else
  \if@tempswa \gdef\and{,\ \scriptsize AND }, \fi
 \fi
 \@tempc\unskip\@tempswatrue\@nextdoa}
\let\and=\relax
%


% Imprime una nota a pie de p�gina sin s�mbolo
% para informacion adicional sobre el articulo
\def\nota#1{
\setcounter{footnote}{0}
\renewcommand{\thefootnote}{}
\footnote{#1} \setcounter{footnote}{0}
\renewcommand{\thefootnote}{\arabic{footnote}}
}
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Definici�n de cabeceras con fancyhdr.sty             %
%Utiliza el paquete ifthen.sty para controlar         %
% la primera p�gina                                   %
%                                                     %
% Definici�n de \nameinheadings y \titleinheadings    %
% que le sirven al autor para definir las             %
% cabeceras abreviadas de las p�ginas                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\gdef\nameinheadings#1{\gdef\@nameinheadings{#1}}
\gdef\@autorenpa{$\backslash$\texttt{nameinheadings}\{N.
Apellido\}}
\let\@nameinheadings=\@autorenpa
%
\gdef\titleinheadings#1{\gdef\@titleinheadings{#1}}
\gdef\@tituloenpa{$\backslash$\texttt{titleinheadings}\{Titulo
corto\}}
\let\@titleinheadings=\@tituloenpa
%
% Selecci�n del estilo de las p�ginas
\pagestyle{fancy} %Selecciona el estilo fancy
\renewcommand{\headrulewidth}{0pt} %Quita la l�nea de cabecera
\fancyhf{} %Pone todo en blanco

%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Logotipo                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
\newcommand{\sema}{\rm S\hbox{\kern-2pt$\vec{\hbox{\kern+2pt e}}$}MA\nolinebreak }
\newcommand{\semados}{\rm S\hbox{\kern-2pt$\vec{\hbox{\kern+2pt e}}$}MA}

\newcommand{\semabold}{{\bf S\hbox{\kern-2pt$\vec{\hbox{\kern+2pt e}}$}MA\nolinebreak} }
\newcommand{\semait}{{\it S\hbox{\kern-2pt$\vec{\hbox{\kern+2pt e}}$}MA\nolinebreak} }
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Secciones, subsecciones, etc...      %
% Disminuimos el tama�o de los titulos %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
\renewcommand\section{\@startsection {section}{1}{\z@}%
                                   {-3.5ex \@plus -1ex \@minus -.2ex}%
                                   {2.3ex \@plus.2ex}%
                                   {\normalfont\normalsize\bfseries}}
\renewcommand\subsection{\@startsection{subsection}{2}{\z@}%
                                     {-3.25ex\@plus -1ex \@minus -.2ex}%
                                     {1.5ex \@plus .2ex}%
                                     {\normalfont\small\bfseries}} %Cambiamos \large por \normalsize
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Keywords & AMS Subject Class.         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
\def\sep{\enspace}
%
\newenvironment{keywords}{\par{\bf
\iflanguage{spanish}{\small Palabras
clave}{\iflanguage{french}{\small Mots-cl�s}{\small Key
words}}:}\hspace{\parindent}\it\small}{\par\normalsize}
%
\newenvironment{AMS}{\par{\bf
\iflanguage{spanish}{\small Clasificaci�n por materias
AMS}{\iflanguage{french}{\small Classement AMS}{\small AMS subject
classifications}}:}\hspace{\parindent}\it\small}{\par\normalsize}
%

\def\encabezado#1{\small  \parbox{.5\textwidth}{\noindent\sl Bol.\ Soc.\ Esp.\ Mat.\ Apl.\newline  n$^o$0 (0000), 1--\pageref{LastPage}}%
}
% Ponemos los contadores a cero
\def\contadores{
\setcounter{section}{0} \setcounter{subsection}{0}
\setcounter{subsubsection}{0} \setcounter{footnote}{0}
\setcounter{equation}{0} \setcounter{figure}{0}
\setcounter{table}{0} \setcounter{theorem}{0}
\setcounter{remark}{0} \setcounter{definition}{0}
\setcounter{example}{0} }

%
%
% Cabeceras

\fancyhead[LE]{\thepage} \fancyhead[RE]{\sf\@nameinheadings}
\fancyhead[CE]{}
%
\fancyhead[RO]{\ifthenelse{\value{page}=1}{}{\thepage}}
\fancyhead[LO]{\ifthenelse{\value{page}=1}{\encabezado}{\sf\@titleinheadings}}
\fancyhead[CO]{}
%



%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Definici�n de funciones y teoremas en espa�ol %
% o en ingles, segun corresponda.              %
%Teoremas, definiciones, etc ... se numeran    %
% todos consecutivamente                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
\DeclareMathOperator{\sinesp}{sen}
\let \sineng=\sin
\renewcommand{\sin}{\iflanguage{spanish}{\sinesp}{\sineng}}
%
\DeclareMathOperator{\arcsinesp}{arcsen}
\let \arcsineng=\arcsin
\renewcommand{\arcsin}{\iflanguage{spanish}{\arcsinesp}{\arcsineng}}
%
\DeclareMathOperator{\tanesp}{tg}
\let \taneng=\tan
\renewcommand{\tan}{\iflanguage{spanish}{\tanesp}{\taneng}}
%
\DeclareMathOperator{\sinhesp}{senh}
\let \sinheng=\sinh
\renewcommand{\sinh}{\iflanguage{spanish}{\sinhesp}{\sinheng}}
%
\DeclareMathOperator{\arctanesp}{arctg}
\let \arctaneng=\arctan
\renewcommand{\arctan}{\iflanguage{spanish}{\arctanesp}{\arctaneng}}
%
\DeclareMathOperator{\cotesp}{cotg}
\let \coteng=\cot
\renewcommand{\cot}{\iflanguage{spanish}{\cotesp}{\coteng}}
%
%
\newtheorem{theorem}{\iflanguage{spanish}{Teorema}{\iflanguage{french}{Th�or�me}{Theorem}}}
\newtheorem{corollary}[theorem]{\iflanguage{spanish}{Corolario}{\iflanguage{french}{Corollaire}{Corollary}}}
\newtheorem{proposition}[theorem]{\iflanguage{spanish}{Proposici�n}{Proposition}}
\newtheorem{lemma}[theorem]{\iflanguage{spanish}{Lema}{\iflanguage{french}{Lemme}{Lemma}}}
\newtheorem{remark}{\iflanguage{spanish}{Nota}{\iflanguage{french}{Remarque}{Remark}}}
\newtheorem{definition}{\iflanguage{spanish}{Definici�n}{Definition}}
\newtheorem{example}{\iflanguage{spanish}{Ejemplo}{Example}}
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Entorno para Demostraciones                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
\newcommand{\proof}[1][\hspace{-1ex}\hspace{2pt}]{\iflanguage{spanish}{%
    \par{\it Demostraci�n #1}. \ignorespaces}{%
    \iflanguage{french}{%
        \par{\it D\`emonstration #1}. \ignorespaces}{%
        \par{\it Proof #1}. \ignorespaces}
    }
}
\def\qed{\ \ \ \hbox{}\nolinebreak\hfill $\square$ \par{}\medskip}
\def\endproof{\nopagebreak\qed}

%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Conjuntos numericos                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
\newcommand{\N}{\ensuremath{\mathbb{N}}}
\newcommand{\Z}{\ensuremath{\mathbb{Z}}}
\newcommand{\Q}{\ensuremath{\mathbb{Q}}}
\newcommand{\R}{\ensuremath{\mathbb{R}}}
\newcommand{\C}{\ensuremath{\mathbb{C}}}
%
%%
\contadores
%% End of file `semacedya.cls'.
